function Footer() {
    return (
      <footer className="text-center py-3 bg-gray-800 text-white fixed bottom-0 w-full">
        &copy; 2025
      </footer>
    );
  }
  
  export default Footer;
  