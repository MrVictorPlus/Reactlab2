import Article from "./Article";

function ArticleList() {
  return (
    <div className="max-w-3xl mx-auto p-4">
      <Article title="Как научиться React?" text="React — это библиотека для создания интерфейсов..." />
      <Article title="Зачем нужен JSX?" text="JSX позволяет писать HTML внутри JavaScript..." />
      <Article title="Компоненты в React" text="Компоненты позволяют переиспользовать код..." />
      <Article title="React и состояние" text="Состояние (state) позволяет компонентам хранить данные..." />
    </div>
  );
}

export default ArticleList;
