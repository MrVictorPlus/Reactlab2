function Article({ title, text }) {
  return (
    <article className="bg-white shadow-md rounded-lg p-6 m-4">
      <h2 className="text-xl font-semibold text-blue-500 mb-2">{title}</h2>
      <p className="text-gray-700">{text}</p>
    </article>
  );
}

export default Article;
