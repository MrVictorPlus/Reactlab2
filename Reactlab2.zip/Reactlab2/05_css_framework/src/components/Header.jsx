function Header() {
  return (
    <header class="bg-blue-500 text-white py-4 text-center">
      <h1 class="text-2xl font-bold">Mini-Blog</h1>
    </header>
  );
}

export default Header;
