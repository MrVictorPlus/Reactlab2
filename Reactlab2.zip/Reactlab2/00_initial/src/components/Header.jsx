function Header() {
    return (
      <header>
        <h1>Mini-Blog</h1>
      </header>
    );
  }
  
  export default Header;
  