function Footer () {
    return (
        <>
        <footer>
            &copy;2025
        </footer>
        </>
    )
}

export default Footer