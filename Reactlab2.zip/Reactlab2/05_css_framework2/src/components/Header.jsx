function Header() {
  return (
    <header className="bg-primary text-white py-4 text-center">
      <h1>Mini-Blog</h1>
    </header>
  );
}

export default Header;
